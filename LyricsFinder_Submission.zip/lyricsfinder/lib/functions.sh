#!/bin/bash

DATA="data/lyrics"
LOG="logs/activity.log"

# Log activity
log() {
    mkdir -p "$(dirname "$LOG")"
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $1" >> "$LOG"
}

# Check lyrics folder
check_data() {
    if [ ! -d "$DATA" ]; then
        echo "Error: Lyrics folder not found: $DATA"
        return 1
    fi
    return 0
}

# Show help
show_help() {
    echo "L73 - Lyrics Finder"
    echo "Usage: ./main.sh [--help | --backup | --cron]"
    echo "Run ./main.sh to open the menu."
}

# View lyrics files
view_data() {
    check_data || return 1
    echo "Lyrics files:"
    find "$DATA" -maxdepth 1 -type f -name "*.txt" -print | sort
    log "Viewed lyrics data"
}

# Backup data
do_backup() {
    mkdir -p backups
    local backup_file="backups/lyrics_$(date +%Y%m%d_%H%M%S).tar.gz"

    if tar -czf "$backup_file" data; then
        echo "Backup created: $backup_file"
        log "Backup created: $backup_file"
    else
        echo "Backup failed."
        log "Backup failed"
        return 1
    fi
}

# View last 15 log lines
view_log() {
    if [ -f "$LOG" ]; then
        tail -n 15 "$LOG"
    else
        echo "No activity log found yet."
    fi
}

# Feature 1: Find songs containing a word
feature_1() {
    check_data || return 1
    read -rp "Enter a word to search: " word

    if [ -z "$word" ]; then
        echo "Please enter a word."
        return 1
    fi

    local found=0 file
    for file in "$DATA"/*.txt; do
        [ -f "$file" ] || continue
        if grep -qiF -- "$word" "$file"; then
            echo "$(basename "$file")"
            found=1
        fi
    done

    [ "$found" -eq 1 ] || echo "No matching songs found."
    log "Searched for word: $word"
}

# Feature 2: Count word occurrences
feature_2() {
    check_data || return 1
    read -rp "Enter a word to count: " word

    if [ -z "$word" ]; then
        echo "Please enter a word."
        return 1
    fi

    local total=0 count file
    for file in "$DATA"/*.txt; do
        [ -f "$file" ] || continue
        count=$(grep -oiwF -- "$word" "$file" | wc -l)
        printf '%s: %s\n' "$(basename "$file")" "$count"
        total=$((total + count))
    done

    echo "Total occurrences: $total"
    log "Counted word: $word (total $total)"
}

# Feature 3: Longest song by number of lines
feature_3() {
    check_data || return 1
    local file lines max_lines=-1 longest=""

    for file in "$DATA"/*.txt; do
        [ -f "$file" ] || continue
        lines=$(wc -l < "$file")
        if [ "$lines" -gt "$max_lines" ]; then
            max_lines=$lines
            longest=$(basename "$file")
        fi
    done

    if [ -n "$longest" ]; then
        echo "Longest song: $longest ($max_lines lines)"
        log "Viewed longest song: $longest"
    else
        echo "No lyrics files found."
    fi
}

# Feature 4: Top 10 most-used words
feature_4() {
    check_data || return 1

    find "$DATA" -maxdepth 1 -type f -name "*.txt" -print0 |
        xargs -0 -r cat |
        tr '[:upper:]' '[:lower:]' |
        tr -cs '[:alnum:]' '\n' |
        grep -v '^$' |
        sort |
        uniq -c |
        sort -nr |
        head -n 10

    log "Viewed top 10 most-used words"
}

# Feature 5: Preview word replacement without changing files
feature_5() {
    check_data || return 1
    read -rp "Word to replace: " old_word
    read -rp "Replace it with: " new_word

    if [ -z "$old_word" ]; then
        echo "Search word cannot be empty."
        return 1
    fi

    local file
    for file in "$DATA"/*.txt; do
        [ -f "$file" ] || continue
        if grep -qiF -- "$old_word" "$file"; then
            echo
            echo "Preview: $(basename "$file")"
            OLD_WORD="$old_word" NEW_WORD="$new_word" \
                awk '{
                    line=$0
                    old=ENVIRON["OLD_WORD"]
                    new=ENVIRON["NEW_WORD"]
                    while ((pos=index(line, old)) > 0) {
                        line=substr(line,1,pos-1) new substr(line,pos+length(old))
                    }
                    print line
                }' "$file"
        fi
    done

    log "Previewed replacement: $old_word -> $new_word"
}

# Generate report for cron
cron_task() {
    check_data || return 1
    mkdir -p reports
    local report="reports/top_words_$(date +%Y%m%d).txt"

    {
        echo "Top 10 Most-Used Words"
        echo "Generated: $(date)"
        find "$DATA" -maxdepth 1 -type f -name "*.txt" -print0 |
            xargs -0 -r cat |
            tr '[:upper:]' '[:lower:]' |
            tr -cs '[:alnum:]' '\n' |
            grep -v '^$' |
            sort |
            uniq -c |
            sort -nr |
            head -n 10
    } > "$report"

    echo "Report saved: $report"
    log "Generated top words report: $report"
}
