#!/bin/bash

cd "$(dirname "$0")" || exit 1
source lib/functions.sh

# Process command-line options
case "${1:-}" in
    --help|-h)
        show_help
        exit 0
        ;;
    --backup)
        do_backup
        exit $?
        ;;
    --cron)
        cron_task
        exit $?
        ;;
esac

# Main menu
while true; do
    echo
    echo "================================"
    echo "       L73 - Lyrics Finder"
    echo "================================"
    echo "1. Find songs containing a word"
    echo "2. Count word occurrences"
    echo "3. Show longest song"
    echo "4. Show top 10 most-used words"
    echo "5. Replace a word (preview only)"
    echo "6. View lyrics data"
    echo "7. Backup data"
    echo "8. View activity log"
    echo "0. Exit"
    echo "================================"

    read -rp "Enter your choice: " choice

    case "$choice" in
        1) feature_1 ;;
        2) feature_2 ;;
        3) feature_3 ;;
        4) feature_4 ;;
        5) feature_5 ;;
        6) view_data ;;
        7) do_backup ;;
        8) view_log ;;
        0)
            echo "Thank you for using Lyrics Finder!"
            log "Application exited"
            break
            ;;
        *)
            echo "Invalid choice. Please enter 0-8."
            ;;
    esac

    read -rp "Press Enter to continue..."
done
